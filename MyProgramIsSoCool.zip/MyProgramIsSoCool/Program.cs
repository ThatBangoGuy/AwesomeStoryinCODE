﻿using System;
using System.Collections.ObjectModel;

namespace MyProgramIsSoCool
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Yurp";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WindowHeight = 40;

            //start of convo
            Console.WriteLine("Hey There Champ! What is ya name!");
            //You say something
            Console.ReadLine();
            //DUDE RUN!
            Console.WriteLine("Oh thats a awesome name.");
            Thread.Sleep(3000);
            Console.WriteLine("Im going to throw this football at your head now!!!!");
            //Say Anything
            Console.ReadLine();
            //Football!
            Console.WriteLine("DUDE I dont care! Im going too hit you with the football!!!! This is going down!!!!");
            Thread.Sleep(3000);
            //Hit by Football!
            Console.WriteLine("Fwoosh thats the sound of a football btw!");
            Thread.Sleep(1000);

            //Storytime
            Console.WriteLine("Hey want to read a story!");
            Console.ReadLine();
            Console.WriteLine("There was a guy named...");
            Console.ReadLine();
            Console.WriteLine("That went to see his dear old grandpa george!");
            Thread.Sleep(2400);
            Console.WriteLine("Then his grandpa took him to...");
            Console.ReadLine();
            Console.WriteLine("They walk in and It was AWESOME!\nThen George Hit His Grandson with a  FUCKIN FOOTBALL! Crash right into your head!!!!!!!!");
            Console.ReadLine();
            

            Console.ReadKey();
        }
    }
}
