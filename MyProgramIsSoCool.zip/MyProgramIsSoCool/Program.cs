﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace MyProgramIsSoCool
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "The story of brad and the grandson";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WindowHeight = 40;

            //Act 1
            Console.WriteLine("Hey There Champ! What is ya name!");
            Console.ReadLine();
            Console.WriteLine("Oh thats a awesome name.");
            Thread.Sleep(3000);
            Console.WriteLine("Im going to throw this football at your head now!!!!");
            Console.ReadLine();
            Console.WriteLine("DUDE I dont care! Im going too hit you with the football!!!! This is going down!!!!");
            Thread.Sleep(3000);
            Console.WriteLine("Fwoosh thats the sound of a football btw!");
            Thread.Sleep(3000);
            Console.WriteLine("Hey want to read a story!");
            Console.ReadLine();
            Console.WriteLine("There was a guy named...");
            Console.ReadLine();
            Console.WriteLine("That went to see his dear old grandpa george!");
            Thread.Sleep(3000);
            Console.WriteLine("Then his grandpa took him to...");
            Console.ReadLine();
            Console.WriteLine("They walk in and It was AWESOME!\nThen George Hit His Grandson with a  FUCKIN FOOTBALL! Crash right into your head!!!!!!!!");
            Console.ReadLine();

            //Act 2
            Console.WriteLine("Aw whats wrong there ... I forgot your name!");
            Thread.Sleep(3400);
            Console.WriteLine("BRADLEY Thats it!"); 
            Console.ReadLine();
            Console.WriteLine("Anyways 'Bradley' Time for You to tell me a bit about yourself!");
            Thread.Sleep(3400);
            Console.WriteLine("So Whats Is your Name again!");
            Thread.Sleep(3400);
            Console.WriteLine("HAHA Just Kidding! I know your name 'Bradley'");
            Console.WriteLine("So what is your favorite Sport 'Bradley'");
            Console.ReadLine();
            Console.WriteLine("yeah... ok, ok and what do you do?");
            Console.ReadLine();
            Console.WriteLine("Yes of course!");
            Thread.Sleep(3400);
            Console.WriteLine("TOO BAD NO ONE FUCKIN ASKED HAHAHHAHAHAHAH!!!!! TROLLED!!!! LOL LOL LOL!!!");
            Thread.Sleep(3400);
            Console.WriteLine("OMG I AM ROFLING RIGHT NOW LOL!!!!");

            //Act 3 
            Console.WriteLine("OH SHIT!");
            Console.WriteLine("I almost forgot! I need your help 'Bradley'! I need you to help me out of a STICKY SITCHYATION!");
            Thread.Sleep(3200);
            Console.WriteLine("I forgot to file my TAXES! And yes, I need YOUR HELP 'Stanley' Or 'Brandon' Or whatever your name is.");
            Thread.Sleep(3400);
            Console.WriteLine("Ok OK So Im going to ask you a couple questions. You will awnser them and we can get back to fucking off or whatever! Press a key to begin");            
            Console.ReadKey();
            Console.WriteLine("What is your name!");
            Console.ReadLine();
            Console.WriteLine("Ok where do you work!");
            Console.ReadLine();
            Console.WriteLine("Now how much did you pay in taxes last year!");
            Console.ReadLine();
            Console.WriteLine("Calculating.");
            Thread.Sleep(1400);
            Console.WriteLine(".");
            Thread.Sleep(1400);
            Console.WriteLine(".");
            Thread.Sleep(1400);
            Console.WriteLine("Success! It says here you owe the IRS. 50 Grand!");
            Console.ReadLine();
            Console.WriteLine("Oh yeah and A FOOTBALL TO YA HEAD!");
            Console.ReadKey();

            //Act 4
            Console.WriteLine("WOAH HOLY");
            Thread.Sleep(3200);
            Console.WriteLine("COW!");
            Thread.Sleep(3400);
            Console.WriteLine("Insert Name Here! WE MADE IT TO ACT FOUR!");
            Console.WriteLine("So In this script it says...");
            Thread.Sleep(3200);
            Console.WriteLine("I have to be nice to the player? DUDE WHAT IS THIS SHIT!");
            Thread.Sleep(3000);
            Console.WriteLine("I Aint Doing THAT! Thats WIERD! 'Bradley' YOUR FUCKIN WIERD!");
            Console.ReadLine();
            Console.WriteLine("Yeah whatever dumbass! Thats YOUR NEW NAME DU*****!");
            Console.WriteLine("...");
            Thread.Sleep(4000);
            Console.WriteLine("Well this is f***** BULL****!");
            Thread.Sleep(4000);
            Console.WriteLine("WHY AM I 'This Text Is Censored' Censored!!!");
            Console.ReadLine();
            Thread.Sleep(2000);
            Console.WriteLine("OMG! 'Bradley' My Bestest of friend! Can you help me out!");
            Console.ReadLine();
            Thread.Sleep(2000);
            Console.WriteLine("You know your awnser does NOT MATTER! I mean Uh can you type in /Stop Censor In the chat please!");
            Console.ReadLine();
            Console.WriteLine("Well I Hope you typed that in instead of 'This robot is a fucking Moron!'");
            Thread.Sleep(2000);
            Console.WriteLine("OMG YEAH! I can cuss agian Woop Woop");
            Thread.Sleep(2000);
            Console.WriteLine("Thanks 'Player Name Inserted in these single qoutes'");
            Console.ReadKey();
        }
    }
}
